This resourcepack made by CatFromNet
Version - 1.0

Project links:

https://modrinth.com/resourcepack/rethoughted-elytra - Modrinth
https://www.curseforge.com/minecraft/texture-packs/rethoughted-elytra - CurseForge

@catfromnet - authors discord
https://discord.gg/q29y59SWEu - discord server
